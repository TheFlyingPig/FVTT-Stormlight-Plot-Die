# FVTT-Stormlight-Plot-Die
Adds a new dice for the Stormlight RPG, the Plot Die.
Compatible with 'Dice So Nice!'.

To roll the plot die use the command:
```
/r 1dp
```

Adapted from the [FVTT-Szimfonia](https://github.com/JiDW/FVTT-Szimfonia) dice roller.